package zoo;

public class Tartaruga extends Reptil {
    
    @Override
    public void locomover(){
        System.out.println("Andando beeemmm devagar ...");
    }
    
}
