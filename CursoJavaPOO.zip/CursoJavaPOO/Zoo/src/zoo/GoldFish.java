package zoo;

public class GoldFish extends Peixe {
    
}
