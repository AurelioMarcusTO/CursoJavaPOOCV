package zoo;

public class Zoo {

    public static void main(String[] args) {
        
        Mamifero m = new Mamifero();
        Reptil r = new Reptil();
        Peixe p = new Peixe();
        Ave a = new Ave();
        Canguru c = new Canguru();
        Cachorro k = new Cachorro();
        Cobra j = new Cobra();
        Tartaruga t = new Tartaruga();
        GoldFish g = new GoldFish();
        Arara ar = new Arara();
        
        
        k.locomover();
        k.reagir("Ola");
        k.reagir(11,45);
        k.reagir(true);
        k.reagir(17,4.5);
        
    }
    
}
