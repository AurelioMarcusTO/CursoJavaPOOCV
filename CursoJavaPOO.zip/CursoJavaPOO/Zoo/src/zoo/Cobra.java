package zoo;

public class Cobra extends Reptil {
    
}
