package zoo;

public class Arara extends Ave {
    
}
