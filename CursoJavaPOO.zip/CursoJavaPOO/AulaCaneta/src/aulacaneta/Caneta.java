
package aulacaneta;

public class Caneta {
   
    private String modelo;
    private String cor;
    private float ponta;
    protected int carga;
    private boolean tampada;
    
    public Caneta(String m, String c, float p){//Este é o método Construtor
        this.modelo = m;
        this.cor = c;
        this.ponta = p;
        this.tampar();
        
    }
    
    public void status(){
        System.out.println("Modelo: " + this.getModelo());
        System.out.println("Uma caneta cor: " + this.getCor());
        System.out.println("Ponta: " + this.getPonta());
        System.out.println("Carga: " + this.getCarga());
        System.out.println("Está tampada ? " + this.getTampada());
    }
    
    public String getModelo(){
        return this.modelo;
    }
    
    public void setModelo(String m){
        this.modelo = m;
    }
    
    public String getCor(){
        return this.cor;
    }
    
    public void setCor(String c){
        this.cor = c;
    }
    
    private float getPonta(){
        return this.ponta;
    }
    
    public void setPonta(float p){
        this.ponta = p;
    }
    
    public int getCarga(){
        return this.carga;
    }
    
    public void setCarga(int c){
        this.carga = c;
    }
    
    public boolean getTampada(){
        return this.tampada;
    }
    
    public void setTampada(boolean t){
        this.tampada = t;
    }
    
    public void rabiscar(){
        if (this.tampada == true){
            System.out.println("ERRO! Não posso rabiscar.");
        } else{
            System.out.println("Estou rabiscando !"); 
        }
        
    }
    
    protected void tampar(){
      this.tampada = true;  
    }
    
    protected void destampar(){
      this.tampada = false;  
    }
    
}
