package projetocremoto;
public class ProjetoCremoto {

    public static void main(String[] args) {
        
        ControleRemoto cr = new ControleRemoto();
        
        //cr.ligar();
        cr.maisVolume();
        //cr.play();
        cr.abrirMenu();
        
    }
    
}
