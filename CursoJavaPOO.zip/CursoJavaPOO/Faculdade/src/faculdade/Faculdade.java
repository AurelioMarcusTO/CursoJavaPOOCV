package faculdade;

public class Faculdade {

    public static void main(String[] args) {
       
     Aluno a1 = new Aluno();
     a1.setNome("Claudio");
     a1.pagarMensalidade();
     Bolsista b2 = new Bolsista();
     b2.setNome("Jubileu");
     b2.pagarMensalidade();
        
        
    }
    
}
