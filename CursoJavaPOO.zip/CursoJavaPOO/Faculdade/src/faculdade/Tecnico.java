package faculdade;

public class Tecnico extends Aluno {
    
    private int registroProfissional;
    
    public void praticar(){
        
    }

    public int getRegistroProfissional() {
        return registroProfissional;
    }

    public void setRegistroProfissional(int registroProfissional) {
        this.registroProfissional = registroProfissional;
    }
    
    
    
}
