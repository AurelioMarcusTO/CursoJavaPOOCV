package faculdade;

public class Visitante extends Pessoa {
    
}
